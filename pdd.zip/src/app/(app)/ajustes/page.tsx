
import { redirect } from 'next/navigation';

export default function AjustesPage() {
  redirect('/ajustes/proyectos');
}
